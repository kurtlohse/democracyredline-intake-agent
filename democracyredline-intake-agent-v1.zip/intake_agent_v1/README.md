# Democracy Redline Intake Agent v1

This package is a deployable first version of a scheduled intake pipeline for Democracy Redline.

It is designed to:
- poll recent news from a configurable feed list
- cluster near-duplicate stories
- use the OpenAI API to triage each cluster
- map stories into Trump Action Tracker domains and Democracy Redline categories
- assign source-quality and status candidates
- write a review queue to CSV and optionally append it to a Google Sheet

## Recommended v1 architecture

- Scheduler: GitHub Actions
- Model triage: OpenAI Responses API
- Review queue: Google Sheet and CSV output
- Human role: editorial review, approval, merge, and scoring decisions

## What it does not do

- It does **not** auto-publish scores
- It does **not** change your site on its own
- It does **not** make final redline decisions without human review

## Folder structure

- `src/main.py` — main intake runner
- `src/fetch_feeds.py` — pulls recent RSS entries
- `src/dedupe.py` — clusters likely duplicate stories
- `src/openai_triage.py` — calls the model for structured recoding
- `src/sheets_writer.py` — writes CSV and optionally appends to Google Sheets
- `config/sources.yaml` — feed list and source quality defaults
- `config/categories.yaml` — Democracy Redline and TAT category reference lists
- `.github/workflows/intake-agent.yml` — scheduled workflow

## Before you deploy

You need:
1. A GitHub repo
2. An OpenAI API key
3. Optionally, a Google Sheet and a Google service account JSON credential

## Local quick start

1. Copy `.env.example` to `.env`
2. Fill in your keys
3. Run:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python src/main.py
```

Your outputs will appear in:
- `output/monthly_intake.csv`
- `output/latest_run.json`

## GitHub deployment steps

1. Create a new GitHub repository, for example: `democracy-redline-intake-agent`
2. Upload the contents of this package
3. In GitHub, open **Settings → Secrets and variables → Actions**
4. Add these repository secrets:
   - `OPENAI_API_KEY`
   - `OPENAI_MODEL` (suggested: `gpt-5-mini`)
   - `GOOGLE_SHEETS_ENABLED` (`true` or `false`)
   - `GOOGLE_SHEET_ID`
   - `GOOGLE_WORKSHEET_NAME`
   - `GOOGLE_SERVICE_ACCOUNT_JSON`
   - `MAX_ITEMS_PER_RUN` (example: `20`)
   - `LOOKBACK_DAYS` (example: `10`)
   - `MIN_CREDIBLE_SOURCES` (example: `2`)

5. Open the **Actions** tab and manually run **Democracy Redline Intake Agent** once
6. Review the generated artifact and, if enabled, the Google Sheet output
7. Leave the schedule on, or edit the cron line in `.github/workflows/intake-agent.yml`

## Cron schedule

Current default:
- Monday at 14:00 UTC
- Thursday at 14:00 UTC

That gives you a twice-weekly intake cadence.

## Google Sheets setup

If you want live review queue output in Google Sheets:

1. Create a Google Sheet
2. Copy its Sheet ID from the URL
3. Create a Google Cloud service account
4. Enable Google Sheets and Drive APIs
5. Share the Sheet with the service-account email as Editor
6. Paste the full JSON credentials into the `GOOGLE_SERVICE_ACCOUNT_JSON` secret
7. Set `GOOGLE_SHEETS_ENABLED=true`

If you do not want to use Google Sheets yet, set `GOOGLE_SHEETS_ENABLED=false` and use the CSV output.

## Output schema

Each intake row contains:
- `event_date`
- `month_bucket`
- `normalized_headline`
- `concise_summary`
- `source_links`
- `source_tiers`
- `corroboration_count`
- `source_quality_assessment`
- `tat_domains`
- `redline_primary`
- `redline_secondary`
- `category_confidence`
- `impact_score`
- `status_candidate`
- `direction`
- `why_it_matters`
- `duplicate_of_existing`
- `review_status`
- `editor_notes`

## Accuracy safeguards built into v1

Use this agent as a triage system, not a score setter.

Recommended editorial rules:
- Do not change a public score based on a single item without human review
- Require at least 2 credible corroborating sources or 1 primary record plus 1 strong secondary source for serious escalations
- Treat `Triggered candidate` as a review flag, not a final decision
- Review every item with high impact score or multi-category mapping

## Suggested next improvements

- stronger deduplication using embeddings
- source whitelist weighting and domain-specific source rules
- monthly summary memo generation
- worksheet export into your historical backfill workbook
- alerting for probable triggered-threshold events
- private dashboard for editorial review
