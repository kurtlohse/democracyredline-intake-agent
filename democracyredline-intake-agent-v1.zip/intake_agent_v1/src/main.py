from __future__ import annotations

import json
from pathlib import Path

from config import ROOT, load_settings, load_yaml
from dedupe import cluster_items
from fetch_feeds import fetch_recent_items
from openai_triage import triage_clusters
from sheets_writer import append_google_sheet, write_csv


def main() -> None:
    settings = load_settings()
    if not settings.openai_api_key:
        raise SystemExit("OPENAI_API_KEY is required. Copy .env.example to .env and fill it in.")

    sources = load_yaml(ROOT / "config" / "sources.yaml")
    categories = load_yaml(ROOT / "config" / "categories.yaml")

    items = fetch_recent_items(sources["feeds"], settings.lookback_days)
    clusters = cluster_items(items)
    triaged = triage_clusters(
        api_key=settings.openai_api_key,
        model=settings.openai_model,
        clusters=clusters,
        categories=categories,
        max_items=settings.max_items_per_run,
    )

    settings.output_csv_path.parent.mkdir(parents=True, exist_ok=True)
    write_csv(triaged, str(settings.output_csv_path))

    if settings.google_sheets_enabled:
        if not settings.google_sheet_id or not settings.google_service_account_json:
            raise SystemExit("Google Sheets is enabled but GOOGLE_SHEET_ID or GOOGLE_SERVICE_ACCOUNT_JSON is missing.")
        append_google_sheet(
            triaged,
            settings.google_sheet_id,
            settings.google_worksheet_name,
            settings.google_service_account_json,
        )

    output_json = Path(ROOT / "output" / "latest_run.json")
    output_json.write_text(json.dumps(triaged, indent=2), encoding="utf-8")
    print(f"Processed {len(triaged)} candidate items.")
    print(f"CSV written to {settings.output_csv_path}")
    if settings.google_sheets_enabled:
        print(f"Appended items to Google Sheet: {settings.google_worksheet_name}")


if __name__ == "__main__":
    main()
