from __future__ import annotations

from typing import Any

import gspread
import pandas as pd
from google.oauth2.service_account import Credentials

SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive",
]

EXPECTED_COLUMNS = [
    "event_date",
    "month_bucket",
    "normalized_headline",
    "concise_summary",
    "source_links",
    "source_tiers",
    "corroboration_count",
    "source_quality_assessment",
    "tat_domains",
    "redline_primary",
    "redline_secondary",
    "category_confidence",
    "impact_score",
    "status_candidate",
    "direction",
    "why_it_matters",
    "duplicate_of_existing",
    "review_status",
    "editor_notes",
]


def write_csv(rows: list[dict[str, Any]], path: str) -> None:
    df = pd.DataFrame(rows)
    for col in EXPECTED_COLUMNS:
        if col not in df.columns:
            df[col] = ""
    df = df[EXPECTED_COLUMNS]
    df.to_csv(path, index=False)


def append_google_sheet(
    rows: list[dict[str, Any]],
    sheet_id: str,
    worksheet_name: str,
    service_account_json: dict[str, Any],
) -> None:
    credentials = Credentials.from_service_account_info(service_account_json, scopes=SCOPES)
    gc = gspread.authorize(credentials)
    sh = gc.open_by_key(sheet_id)
    try:
        ws = sh.worksheet(worksheet_name)
    except gspread.WorksheetNotFound:
        ws = sh.add_worksheet(title=worksheet_name, rows=500, cols=len(EXPECTED_COLUMNS) + 5)
        ws.append_row(EXPECTED_COLUMNS)

    values = []
    for row in rows:
        row = {**row}
        row.setdefault("review_status", "New")
        row.setdefault("editor_notes", "")
        values.append([_stringify(row.get(col, "")) for col in EXPECTED_COLUMNS])
    if values:
        ws.append_rows(values, value_input_option="USER_ENTERED")


def _stringify(value: Any) -> str:
    if isinstance(value, list):
        return " | ".join(str(v) for v in value)
    return str(value)
