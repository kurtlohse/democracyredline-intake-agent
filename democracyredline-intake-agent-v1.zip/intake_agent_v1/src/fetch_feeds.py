from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from typing import Any

import feedparser


@dataclass
class FeedItem:
    source_name: str
    feed_url: str
    source_tier: str
    source_reliability: float
    title: str
    link: str
    published_at: str
    summary: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _parse_date(entry: Any) -> datetime | None:
    if getattr(entry, "published", None):
        try:
            dt = parsedate_to_datetime(entry.published)
            return dt.astimezone(timezone.utc) if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
        except Exception:
            return None
    return None


def fetch_recent_items(feeds: list[dict[str, Any]], lookback_days: int) -> list[FeedItem]:
    cutoff = datetime.now(timezone.utc) - timedelta(days=lookback_days)
    items: list[FeedItem] = []

    for feed in feeds:
        parsed = feedparser.parse(feed["url"])
        for entry in parsed.entries:
            dt = _parse_date(entry)
            if dt and dt < cutoff:
                continue
            items.append(
                FeedItem(
                    source_name=feed["name"],
                    feed_url=feed["url"],
                    source_tier=feed["source_tier"],
                    source_reliability=float(feed.get("reliability", 0.8)),
                    title=getattr(entry, "title", "").strip(),
                    link=getattr(entry, "link", "").strip(),
                    published_at=(dt.isoformat() if dt else ""),
                    summary=getattr(entry, "summary", "").strip(),
                )
            )
    return items
