from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.lib.units import inch
from reportlab.graphics.shapes import Drawing, Rect, String, Line
from reportlab.graphics.charts.lineplots import LinePlot
from reportlab.graphics.widgets.markers import makeMarker
from reportlab.graphics import renderPDF
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import qrcode
from PIL import Image as PILImage
import os, math

OUT_PDF = '/mnt/data/workfix/assets/march-2026-scorecard.pdf'
OUT_PNG = '/mnt/data/workfix/assets/march-2026-scorecard.png'
OUT_WEBP = '/mnt/data/workfix/assets/march-2026-scorecard.webp'
CHART = '/mnt/data/workfix/assets/_march_chart.png'
QR = '/mnt/data/workfix/assets/_qr.png'

score = 8.9
velocity = 0.5
month = 'MARCH 2026'

# band colors for 0-3, 4-6, 7-8.9, 9-10
GREEN = (0x96/255, 0xC7/255, 0x79/255)
LIGHT_ORANGE = (0xF3/255, 0xB3/255, 0x6A/255)
DARK_ORANGE = (0xC8/255, 0x5A/255, 0x10/255)
RED = (0xD9/255, 0x3A/255, 0x2F/255)
TEXT = colors.HexColor('#0f172a')
MUTED = colors.HexColor('#64748b')
BORDER = colors.HexColor('#d1d5db')
PANEL = colors.HexColor('#f2f4f7')


def rgb_to_hex(rgb):
    return '#%02x%02x%02x' % tuple(max(0,min(255,round(c*255))) for c in rgb)


def lerp(a, b, t):
    return tuple(a[i] + (b[i]-a[i])*t for i in range(3))


def score_color(s):
    if s <= 3:
        t = s/3 if 3 else 0
        base = lerp((0.78,0.90,0.77), GREEN, t)
    elif s <= 6:
        t = (s-3)/3
        base = lerp(GREEN, LIGHT_ORANGE, t)
    elif s <= 9:
        t = (s-6)/3
        base = lerp(LIGHT_ORANGE, DARK_ORANGE, t)
    else:
        t = min(1,(s-9)/1)
        base = lerp(DARK_ORANGE, RED, t)
    return base

HEADER = colors.HexColor(rgb_to_hex(score_color(score)))

# chart
months = ['Oct','Nov','Dec','Jan','Feb','Mar']
values = [7.6, 7.8, 8.0, 8.2, 8.4, 8.9]
fig = plt.figure(figsize=(8, 2.7), dpi=200)
ax = fig.add_subplot(111)
ax.axhspan(0, 3, facecolor='#cfe5cd', alpha=1)
ax.axhspan(3, 4, facecolor='#f4e3cc', alpha=1)
ax.axhspan(4, 7, facecolor='#f0d5b3', alpha=1)
ax.axhspan(7, 9, facecolor='#edbf8d', alpha=1)
ax.axhspan(9, 10, facecolor='#f08f88', alpha=1)
ax.plot(months, values, marker='o', linewidth=1.8)
ax.set_ylim(0, 10)
ax.set_ylabel('Score')
ax.set_xlabel('Month')
ax.spines[['top','right']].set_visible(False)
ax.grid(axis='y', alpha=0.15)
plt.tight_layout()
fig.savefig(CHART, bbox_inches='tight', facecolor='white')
plt.close(fig)

# qr
img = qrcode.make('https://democracyredline.com/methodology.html#redlines-explained')
img.save(QR)

styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name='TitleCustom', fontName='Helvetica-Bold', fontSize=24, leading=27, textColor=TEXT, spaceAfter=6))
styles.add(ParagraphStyle(name='BodyCustom', fontName='Helvetica', fontSize=11, leading=14, textColor=TEXT))
styles.add(ParagraphStyle(name='SmallMuted', fontName='Helvetica-Oblique', fontSize=8.5, leading=10.5, textColor=MUTED))
styles.add(ParagraphStyle(name='SectionHead', fontName='Helvetica-Bold', fontSize=11.5, leading=14, textColor=colors.HexColor('#1f2937'), spaceAfter=4))
styles.add(ParagraphStyle(name='BoxBody', fontName='Helvetica', fontSize=10.5, leading=13.2, textColor=colors.HexColor('#1f2937')))
styles.add(ParagraphStyle(name='Legend', fontName='Helvetica', fontSize=9.3, leading=11, textColor=colors.HexColor('#475569')))
styles.add(ParagraphStyle(name='Status', fontName='Helvetica-Bold', fontSize=10.3, leading=12, alignment=TA_CENTER))


class MarchDoc:
    def __init__(self, path):
        self.c = canvas.Canvas(path, pagesize=letter)
        self.w, self.h = letter

    def header(self):
        c = self.c
        band_h = 28
        band_y = self.h - 78  # lower than before
        c.setFillColor(HEADER)
        c.roundRect(54, band_y, self.w - 108, band_h, 0, fill=1, stroke=0)
        c.setFillColor(colors.white)
        c.setFont('Helvetica-Bold', 11.8)
        c.drawString(64, band_y + 9, f'LAST UPDATED SCORE: {score:.1f} / 10 | {month} | VELOCITY ▲ {velocity:.1f}')

    def page1(self):
        c=self.c
        self.header()
        y = self.h - 150
        c.setFillColor(TEXT)
        c.setFont('Helvetica-Bold', 30)
        c.drawString(62, y, 'U.S. Democracy Risk Assessment')
        y -= 18
        summary = ('Executive Summary: Democratic institutions remain operational but are under sustained structural\n'
                   'stress, with March now showing a broader escalation across press freedom, election administration,\n'
                   'court compliance, and executive power.')
        text = c.beginText(62, y)
        text.setFont('Helvetica', 11.6)
        text.setLeading(14)
        for line in summary.split('\n'):
            text.textLine(line)
        c.drawText(text)
        y -= 72
        # score table
        data = [
            ['Category','Score'],
            ['Rule of Law & Court Compliance','8.7'],
            ['Habeas Corpus & Due Process','8.5'],
            ['Coercive State Power','8.2'],
            ['Weaponized Justice','8.0'],
            ['Election Integrity','8.6'],
            ['Press Freedom','7.4'],
            ['Civil Society','6.8'],
            ['Institutional Oversight','8.0'],
            ['Military / Intelligence Neutrality','8.8'],
        ]
        tbl = Table(data, colWidths=[420, 72], rowHeights=[28]+[28]*9)
        tbl.setStyle(TableStyle([
            ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#d9dde3')),
            ('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),
            ('FONTSIZE',(0,0),(-1,-1),10.5),
            ('TEXTCOLOR',(0,0),(-1,-1),TEXT),
            ('GRID',(0,0),(-1,-1),0.5,BORDER),
            ('ALIGN',(1,1),(1,-1),'CENTER'),
            ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
            ('LEFTPADDING',(0,0),(-1,-1),10), ('RIGHTPADDING',(0,0),(-1,-1),10),
        ]))
        tw, th = tbl.wrapOn(c, 0, 0)
        tbl.drawOn(c, 62, y - th)
        y -= th + 14
        # narrative box
        c.setFillColor(colors.HexColor('#eef1f5'))
        c.rect(62, y-46, 492, 42, fill=1, stroke=0)
        c.setStrokeColor(colors.HexColor('#cfd6de'))
        c.rect(62, y-46, 492, 42, fill=0, stroke=1)
        text = c.beginText(72, y-18)
        text.setFont('Helvetica', 10.2)
        text.setLeading(12)
        text.setFillColor(colors.HexColor('#1f2937'))
        text.textOut('Trend Line Narrative: ')
        text.setFont('Helvetica', 10.2)
        text.textLine('March moved the index from 8.4 to 8.9 as a triggered press-freedom redline')
        text.textLine('and a new election-override Watch signal widened the constitutional-risk pattern beyond the')
        text.textLine('domains that had already deteriorated earlier in the month.')
        c.drawText(text)
        y -= 220
        # chart
        chart_img = ImageReader(CHART)
        c.drawImage(chart_img, 80, y, width=440, height=150, preserveAspectRatio=True, mask='auto')
        # legend text
        ly = y - 16
        c.setFont('Helvetica', 9.8)
        items = [
            ('Green ', '#2f8f3b', '0–3 Stable'),
            ('Light Orange ', '#d97706', '4–6 Stress'),
            ('Dark Orange ', '#c85a10', '7–8.9 Severe Erosion'),
            ('Red ', '#dc2626', '9–10 Breakdown Risk'),
        ]
        x = 62
        for label, color, desc in items:
            c.setFillColor(colors.HexColor(color))
            c.drawString(x, ly, label)
            x += c.stringWidth(label, 'Helvetica', 9.8)
            c.setFillColor(colors.HexColor('#475569'))
            c.drawString(x, ly, desc)
            x += c.stringWidth(desc + '   ', 'Helvetica', 9.8) + 12
        c.showPage()

    def page2(self):
        c=self.c
        y=self.h-70
        c.setFillColor(colors.HexColor('#1f2937'))
        c.setFont('Helvetica-Bold', 16)
        c.drawString(62, y, 'Redline Tracker')
        y -= 10
        data = [
            ['Indicator','Status'],
            ['Final Supreme Court order openly defied','Watch'],
            ['Habeas / counsel access functionally inaccessible','Watch'],
            ['Opposition leader jailed on speech-based charge','Not Triggered'],
            ['Federal override of certified election results','Watch'],
            ['Journalists criminally charged for routine reporting','Triggered'],
            ['Intelligence used for domestic political surveillance','Watch'],
        ]
        tbl = Table(data, colWidths=[430, 80], rowHeights=[28]+[28]*6)
        ts = [
            ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#d9dde3')),
            ('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),
            ('FONTSIZE',(0,0),(-1,-1),10.3),
            ('TEXTCOLOR',(0,0),(-1,-1),TEXT),
            ('GRID',(0,0),(-1,-1),0.5,BORDER),
            ('ALIGN',(1,1),(1,-1),'CENTER'), ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
            ('LEFTPADDING',(0,0),(-1,-1),10), ('RIGHTPADDING',(0,0),(-1,-1),10),
            ('TEXTCOLOR',(1,1),(1,2),colors.HexColor('#b45309')),
            ('TEXTCOLOR',(1,3),(1,3),colors.HexColor('#6b7280')),
            ('TEXTCOLOR',(1,4),(1,4),colors.HexColor('#b45309')),
            ('TEXTCOLOR',(1,5),(1,5),colors.HexColor('#dc2626')),
            ('TEXTCOLOR',(1,6),(1,6),colors.HexColor('#b45309')),
        ]
        tbl.setStyle(TableStyle(ts))
        tw, th = tbl.wrapOn(c,0,0)
        tbl.drawOn(c,62,y-th)
        y -= th + 14
        c.setFillColor(colors.HexColor('#eef5ff'))
        c.setStrokeColor(colors.HexColor('#93c5fd'))
        c.rect(62, y-78, 492, 70, fill=1, stroke=1)
        t = c.beginText(72, y-28)
        t.setFillColor(colors.HexColor('#1f2937'))
        t.setFont('Helvetica-Bold', 10.7)
        t.textLine('Why the March score is now 8.9')
        t.setFont('Helvetica', 10.2)
        t.setLeading(12)
        t.textLine('The March report is being revised upward because the live tracker and the PDF are now aligned.')
        t.textLine('Two developments changed the picture: the journalist-charges redline moved to Triggered, and')
        t.textLine('the federal-election-override indicator moved to Watch. Those shifts broaden the danger pattern')
        t.textLine('across institutions rather than leaving it concentrated in only one or two domains.')
        c.drawText(t)
        y -= 102
        c.setFillColor(colors.HexColor('#1f2937'))
        c.setFont('Helvetica-Bold', 16)
        c.drawString(62, y, 'What could still slow the escalation')
        y -= 10
        actions = [
            ['1. Force visible court\ncompliance', 'Orders need documented compliance steps, deadlines, and\nconsequences for delay or evasive narrowing.'],
            ['2. Treat routine reporting as\ndemocratic infrastructure', 'Criminalizing ordinary protest coverage should trigger coordinated legal,\ncivic, and institutional response before the practice normalizes.'],
            ['3. Defend election record\ncustody', 'Ballots, election equipment, and certification records should stay inside\nclearly lawful procedures with transparent judicial oversight.'],
            ['4. Preserve counsel and\nhabeas access in real time', 'Rights that are technically available but practically unreachable\naccelerate coercive abuses and reduce correction capacity.'],
        ]
        atbl = Table(actions, colWidths=[160, 332], rowHeights=[46]*4)
        atbl.setStyle(TableStyle([
            ('GRID',(0,0),(-1,-1),0.5,BORDER),
            ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
            ('LEFTPADDING',(0,0),(-1,-1),10), ('RIGHTPADDING',(0,0),(-1,-1),10),
            ('FONTNAME',(0,0),(0,-1),'Helvetica-Bold'),
            ('FONTSIZE',(0,0),(-1,-1),9.6),
            ('TEXTCOLOR',(0,0),(-1,-1),colors.HexColor('#1f2937')),
        ]))
        tw, th = atbl.wrapOn(c,0,0)
        atbl.drawOn(c,62,y-th)
        y -= th + 18
        c.setFillColor(colors.HexColor('#1f2937'))
        c.setFont('Helvetica-Bold', 16)
        c.drawString(62, y, 'Bottom line')
        y -= 8
        c.setFillColor(colors.HexColor('#fff1f0'))
        c.setStrokeColor(colors.HexColor('#fca5a5'))
        c.rect(62, y-58, 430, 50, fill=1, stroke=1)
        t = c.beginText(74, y-24)
        t.setFillColor(colors.HexColor('#1f2937'))
        t.setFont('Helvetica', 10.4)
        t.setLeading(12.5)
        t.textLine('March now reads as a widening constitutional danger pattern, not just a one-domain spike. The')
        t.textLine('revised score of 8.9 keeps the system in severe erosion, one step below formal breakdown risk,')
        t.textLine('while signaling that further redline movement could produce a much faster jump than ordinary')
        t.textLine('monthly drift.')
        c.drawText(t)
        # methodology
        c.setFillColor(MUTED)
        meth = ('Methodology: Composite index derived from a structured rubric assessing rule of law, due process,\n'
                'election integrity, institutional independence, civil liberties, and coercive state power. Scores are\n'
                'weighted by severity and evidence strength, with primary emphasis on court rulings, statutes,\n'
                'executive actions, federal dockets, and verified reporting. Authored by Kurt Lohse with research\n'
                'and analytical support from ChatGPT (GPT-5 class model).')
        text = c.beginText(62, 76)
        text.setFont('Helvetica-Oblique', 8.6)
        text.setLeading(10.2)
        for ln in meth.split('\n'):
            text.textLine(ln)
        c.drawText(text)
        qr = ImageReader(QR)
        c.drawImage(qr, 466, 74, width=56, height=56, mask='auto')
        c.setFont('Helvetica', 9)
        c.drawRightString(548, 52, 'Methodology & details')
        c.showPage()

    def save(self):
        self.c.save()

md = MarchDoc(OUT_PDF)
md.page1()
md.page2()
md.save()
