Democracy Redline - production package

What changed in this package
- Added Mission page
- Updated nav across all pages
- Simplified production asset names:
  - /assets/march-2026-scorecard.pdf
  - /assets/march-2026-scorecard.png
  - /assets/feb-2026-scorecard.pdf
- Fixed homepage CTA to use the simplified March PDF path
- Updated attribution language to: research and analytical support from OpenAI's ChatGPT (GPT-5 class model)

How to deploy
Upload the entire ZIP to Netlify. Do not upload subfolders individually.