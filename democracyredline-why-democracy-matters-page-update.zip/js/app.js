async function loadData(){
  const res = await fetch('/data/site-data.json');
  if(!res.ok) throw new Error('Failed to load site data');
  return res.json();
}
function statusPill(status){
  if(status==='Critical') return '<span class="pill red">Critical</span>';
  if(status==='Watch') return '<span class="pill orange">Watch</span>';
  return '<span class="pill green">'+status+'</span>';
}
function redlinePill(status, link, label){
  const cls = status==='Watch' ? 'orange' : status==='Triggered' ? 'red' : 'green';
  const text = status==='Watch' ? 'Watch' : status==='Triggered' ? 'Triggered' : 'Not Triggered';
  const inner = `<span class=\"pill ${cls}\">${text}</span>`;
  if(link){
    const title = label || 'Open source story';
    return `<a class=\"status-link\" href=\"${link}\" target=\"_blank\" rel=\"noopener\" title=\"${title}\" aria-label=\"${title}\">${inner}</a>`;
  }
  return inner;
}
function redlineVisual(data){
  const triggered = data.redlines.filter(r=>r.status==='Triggered').length;
  const watch = data.redlines.filter(r=>r.status==='Watch').length;
  const safe = data.redlines.length - triggered - watch;
  return `
    <div class="redline-visual-wrap">
      <div class="redline-thermometer" aria-hidden="true">
        <div class="redline-fill"></div>
        <div class="redline-glow"></div>
        <div class="redline-marker marker-safe">Monitor</div>
        <div class="redline-marker marker-watch">Escalating</div>
        <div class="redline-marker marker-hit">Redline</div>
      </div>
      <div class="redline-visual-copy">
        <div class="redline-alert">Democratic danger rises sharply when a redline is crossed.</div>
        <div class="redline-counts">
          <span><strong>${triggered}</strong> Triggered</span>
          <span><strong>${watch}</strong> On watch</span>
          <span><strong>${safe}</strong> Not triggered</span>
        </div>
        <p class="small">Think of the score as the climate. Think of redlines as the lightning strikes. They are discrete events that can rapidly move the country from severe erosion toward outright constitutional danger.</p>
        <button class="text-button inline-link" type="button" data-redline-explainer="true">What the redline means</button>
      </div>
    </div>`;
}
function modalTemplate(){
  return `
  <div class="modal-backdrop" id="indicatorModal" hidden>
    <div class="modal-panel" role="dialog" aria-modal="true" aria-labelledby="indicatorModalTitle">
      <button class="modal-close" id="indicatorModalClose" aria-label="Close">×</button>
      <div class="small modal-kicker" id="indicatorModalKicker">Redline indicator</div>
      <h3 id="indicatorModalTitle">Indicator</h3>
      <div id="indicatorModalBody"></div>
    </div>
  </div>`;
}
function bindIndicatorModal(data){
  if(!document.getElementById('indicatorModalMount')) return;
  document.getElementById('indicatorModalMount').innerHTML = modalTemplate();
  const backdrop = document.getElementById('indicatorModal');
  const closeBtn = document.getElementById('indicatorModalClose');
  const titleEl = document.getElementById('indicatorModalTitle');
  const kickerEl = document.getElementById('indicatorModalKicker');
  const bodyEl = document.getElementById('indicatorModalBody');
  const openButtons = document.querySelectorAll('[data-redline-id]');
  const explainerButtons = document.querySelectorAll('[data-redline-explainer]');
  function closeModal(){
    backdrop.hidden = true;
    document.body.classList.remove('modal-open');
  }
  function openModal({kicker,title,body}){
    kickerEl.textContent = kicker;
    titleEl.textContent = title;
    bodyEl.innerHTML = body;
    backdrop.hidden = false;
    document.body.classList.add('modal-open');
  }
  openButtons.forEach(btn=>btn.addEventListener('click', ()=> {
    const item = data.redlines.find(r=>r.id===btn.dataset.redlineId);
    if(!item) return;
    openModal({
      kicker: 'Redline indicator',
      title: item.indicator,
      body: `
        <div style="margin-bottom:12px">${redlinePill(item.status, item.statusLink, item.statusSource)}</div>
        <div class="stack modal-stack">
          <div>
            <div class="small modal-label">What it represents</div>
            <p>${item.description}</p>
          </div>
          <div>
            <div class="small modal-label">Why it matters</div>
            <p>${item.importance}</p>
          </div>
          <div>
            <div class="small modal-label">Trigger threshold</div>
            <p>${item.threshold}</p>
          </div>
          <div>
            <div class="small modal-label">Why it is prioritized</div>
            <p>${item.whyNow}</p>${item.statusLink ? `<p class=\"small\" style=\"margin-top:10px\"><a href=\"${item.statusLink}\" target=\"_blank\" rel=\"noopener\">Latest significant status-change story</a></p>` : ''}
          </div>
        </div>`
    });
  }));
  explainerButtons.forEach(btn=>btn.addEventListener('click', ()=> {
    openModal({
      kicker: 'Redline framework',
      title: 'What the redline means',
      body: `
        <div class="stack modal-stack">
          <div>
            <div class="small modal-label">What a redline is</div>
            <p>A redline is a threshold event that materially changes the level of democratic danger if credibly met. The score measures accumulation over time. A redline marks a more abrupt constitutional shock.</p>
          </div>
          <div>
            <div class="small modal-label">Why it matters</div>
            <p>Some developments do not merely add risk. They change the kind of system people are living in. Court defiance, politically motivated jailing, criminalized reporting, or override of certified election results can rapidly collapse the practical value of ordinary democratic safeguards.</p>
          </div>
          <div>
            <div class="small modal-label">How the tracker uses it</div>
            <p>Each redline is labeled Not Triggered, Watch, or Triggered. Watch means there is meaningful evidence of movement toward the threshold. Triggered means the site judges that the threshold has been credibly crossed based on the strongest available evidence, even if broader legal or political debate continues afterward.</p>
          </div>
          <div>
            <div class="small modal-label">Learn more</div>
            <p><a href="/methodology.html#redlines-explained">Read the full methodology section</a></p>
          </div>
        </div>`
    });
  }));
  closeBtn.addEventListener('click', closeModal);
  backdrop.addEventListener('click', (e)=> { if(e.target===backdrop) closeModal(); });
  document.addEventListener('keydown', (e)=> { if(e.key==='Escape' && !backdrop.hidden) closeModal(); });
}
async function renderHome(){
  const data = await loadData();
  document.querySelectorAll('[data-score]').forEach(el=>el.textContent=data.site.currentScore.toFixed(1));
  document.querySelectorAll('#scorePrev').forEach(el=>el.textContent=data.site.previousScore.toFixed(1));
  document.querySelectorAll('#velocity').forEach(el=>el.textContent='+'+data.site.velocity.toFixed(1));
  if(document.getElementById('statusLabel')) document.getElementById('statusLabel').textContent = data.site.statusLabel || 'Near Redline';
  if(document.getElementById('statusSub')) document.getElementById('statusSub').textContent = data.site.statusSub || ''; 
  document.getElementById('updated').textContent = data.site.updated;
  document.getElementById('site-tagline').textContent = data.site.tagline;
  document.getElementById('categoryRows').innerHTML = data.categories.map(c=>`<tr><td>${c.name}</td><td>${c.score.toFixed(1)}</td></tr>`).join('');
  document.getElementById('criticalEvents').innerHTML = data.criticalEvents.map(ev=>`<article class="event"><div class="event-head"><div><div class="tag">${ev.category}</div><h3>${ev.title}</h3></div>${statusPill(ev.status)}</div><p>${ev.summary}</p><div class="small" style="margin-top:10px"><strong>Score move:</strong> ${ev.scoreMove}</div></article>`).join('');
  document.getElementById('redlineVisual').innerHTML = redlineVisual(data);
  document.getElementById('redlineRows').innerHTML = data.redlines.map(r=>`<tr><td><div class="indicator-cell"><div class="indicator-title">${r.indicator}</div><button class="text-button" data-redline-id="${r.id}">Why this matters</button></div></td><td>${redlinePill(r.status, r.statusLink, r.statusSource)}</td></tr>`).join('');
  document.getElementById('sourceList').innerHTML = data.sources.map(s=>`<div class="source-item"><div><div><strong>${s.name}</strong></div><div class="small">${s.use}</div></div><a href="${s.link}" target="_blank" rel="noopener">Visit</a></div>`).join('');
  document.getElementById('roadmapList').innerHTML = data.roadmap.map(x=>`<li>${x}</li>`).join('');
  bindIndicatorModal(data);
}
async function renderAnalysis(){
  const data = await loadData();
  document.getElementById('analysisSummary').innerHTML = `<strong>March 2026 update:</strong> Previous overall ${data.site.previousScore.toFixed(1)} / 10. Updated overall ${data.site.currentScore.toFixed(1)} / 10. Under the published Version 1.0 model, that places the system <strong>near redline</strong> because the danger is widening across war powers, election administration, press freedom, and court compliance at the same time.`;
}
document.addEventListener('DOMContentLoaded', ()=> {
  if(document.body.dataset.page==='home') renderHome();
  if(document.body.dataset.page==='analysis') renderAnalysis();
});
